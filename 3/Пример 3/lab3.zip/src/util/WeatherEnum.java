package util;

public enum WeatherEnum {
    CLOUDY, RAINY, SUNNY, SNOWY
}
