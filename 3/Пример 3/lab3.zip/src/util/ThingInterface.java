package util;

public interface ThingInterface {
    String getName();
}
