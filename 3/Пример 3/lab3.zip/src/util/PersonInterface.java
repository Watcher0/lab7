package util;

public interface PersonInterface extends ThingInterface {
    boolean isSitting();

    boolean isUpsideDown();

    boolean isBelieving();
}
